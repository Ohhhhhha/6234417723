package lab2_1;
import java.awt.Rectangle;
import java.util.Random;

public class recrandom {

    public static void main(String[] args) {
       Random generator = new Random();
       int r1X = generator.nextInt(50)+1;
       int r1Y = generator.nextInt(50)+1;
       int r1width = generator.nextInt(50)+1;
       int r1height = generator.nextInt(50)+1;
         
       int r2X = generator.nextInt(50)+1;
       int r2Y = generator.nextInt(50)+1;
       int r2width = generator.nextInt(50)+1;
       int r2height = generator.nextInt(50)+1;
       
       Rectangle r1 = new Rectangle(r1X,r1Y,r1width,r1height);
       Rectangle r2 = new Rectangle(r2X,r2Y,r2width,r2height);
       System.out.println(r1);
       System.out.println(r2);
       Rectangle r3 = r1.intersection(r2);
       System.out.println("Is the intersected rectangle empty?:"+r3.isEmpty());
    }
    
}
