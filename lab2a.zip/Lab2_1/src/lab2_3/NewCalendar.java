
package lab2_3;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class NewCalendar {
    public static void main(String[] args) {
        GregorianCalendar today = new GregorianCalendar(2020,Calendar.JANUARY,24);
        GregorianCalendar birthday = new GregorianCalendar(2001,Calendar.FEBRUARY,9);
        today.add(Calendar.DAY_OF_MONTH, 100);
        birthday.add(Calendar.DAY_OF_MONTH, 1000);
        
        String weekdayToday = String.valueOf(today.get(Calendar.DAY_OF_WEEK));
        String dayToday = String.valueOf(today.get(Calendar.DAY_OF_MONTH));
        String monthToday = String.valueOf(today.get(Calendar.MONTH));
        String yearToday = String.valueOf(today.get(Calendar.YEAR));
        
        String weekdayBirthday = String.valueOf(birthday.get(Calendar.DAY_OF_WEEK));
        String dayBirthday = String.valueOf(birthday.get(Calendar.DAY_OF_MONTH));
        String monthBirthday = String.valueOf(birthday.get(Calendar.MONTH));
        String yearBirthday = String.valueOf(birthday.get(Calendar.YEAR));
        
        System.out.println(weekdayToday+" "+dayToday+" "+monthToday+" "+yearToday);
        System.out.println(weekdayBirthday+" "+dayBirthday+" "+monthBirthday+" "+yearBirthday);
    }
    
}
