/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author Yanisa
 */
public class Car {
    private double gas, efficiency;
    public Car(double gas, double efficiency){
        setGas(gas);
        this.efficiency = efficiency;
    }
    public void drive(double distance){
        double usedGas= distance/efficiency;
        if (usedGas <= gas) gas -= usedGas;
        else System.out.println("You cannot drive too far, please add gas.");
    }
    // setter
    public void setGas(double amount){
        this.gas = amount;
    }
    public double getGas(){
        return gas;
    }
    public double getEfficiency(){
        return efficiency;
    }
    public void addGas(double amount){
        gas += amount;
    }
    
}
