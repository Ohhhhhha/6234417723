package lab8_1;

public class Truck extends Car {
    private double weight,M_weight;
    
    public Truck(double gas, double efficiency,double M_weight,double weight) {
        super(gas, efficiency);
        if (weight > M_weight) this.weight = M_weight;
        else this.weight = weight;
    }
    @Override
    public void drive(double distance){
        double usedGas= distance/getEfficiency();
        if(weight>=1 & weight <=10) usedGas += usedGas*0.1;
        else if(weight>=11 & weight <=20) usedGas += usedGas*0.2;
        else if(weight>20) usedGas += usedGas*0.3;
        if (usedGas <= getGas()) setGas(getGas()-usedGas);
        else System.out.println("You cannot drive too far, please add gas.");
    }
}