package com.example.youeat;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

public class FoxView extends View {

    private Bitmap fox[] = new Bitmap[2] ;
    private int foxX = 10;
    private int foxY;
    private int foxSpeed ;

    private int canvasWidth,canvasHeight;

    private  Bitmap food;
    private int foodX,foodY, foodSpeed =16;
    private Bitmap virus;
    private int virusX,virusY,virusSpeed=20;

    private int score;

    private boolean touch = false;

    private Bitmap backgroundImage ;
    private Paint scorePaint = new Paint() ;
    private Bitmap life[] = new Bitmap[2];

    public FoxView(Context context) {
        super(context);

        fox[0] = BitmapFactory.decodeResource(getResources(), R.drawable.playfox) ;
        fox[1] = BitmapFactory.decodeResource(getResources(), R.drawable.playfox) ;

        backgroundImage = BitmapFactory.decodeResource(getResources(), R.drawable.background02) ;

        scorePaint.setColor(Color.WHITE) ;
        scorePaint.setTextSize(70) ;
        scorePaint.setTypeface(Typeface.DEFAULT_BOLD) ;
        scorePaint.setAntiAlias(true) ;

        life[0] = BitmapFactory.decodeResource(getResources(),R.drawable.hearts);
        life[1] = BitmapFactory.decodeResource(getResources(),R.drawable.heart_grey);

        foxY = 550;

        food = BitmapFactory.decodeResource(getResources(),R.drawable.food01);
        virus = BitmapFactory.decodeResource(getResources(),R.drawable.virus01);

        score = 0;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvasWidth = canvas.getWidth();
        canvasHeight = canvas.getHeight();

        canvas.drawBitmap(backgroundImage,0,0,null) ;
        canvas.drawBitmap(food,foodX,foodY,null);
        int minFoxY= fox[0].getHeight();
        int maxFoxY = canvasHeight - fox[0].getHeight() * 3;
        foxY = foxY + foxSpeed;
        if (foxY < minFoxY){
            foxY = minFoxY;
        }
        if (foxY > maxFoxY){
            foxY = maxFoxY;
        }
        foxSpeed = foxSpeed+2;

        if (touch)
        {
            canvas.drawBitmap(fox[1],foxX,foxY,null);
            touch = false;
        }
        else
        {
            canvas.drawBitmap(fox[0],foxX,foxY,null);
        }

        canvas.drawText("Score : "+ score ,20,60,scorePaint) ;

        canvas.drawBitmap(life[0],580,10,null);
        canvas.drawBitmap(life[0],680,10,null);
        canvas.drawBitmap(life[0],780,10,null);

        foodX = foodX - foodSpeed;
        if (hitFoodChecker(foodX, foodY))
        {
            score = score + 10;
            foodX = -100;
        }

        if(foodX < 0)
        {
            foodX = canvasWidth + 21;
            foodY = (int)Math.floor(Math.random()*(maxFoxY-minFoxY))+minFoxY;
        }
    }

    public boolean hitFoodChecker(int x, int y)
    {
        if(foxX < x && x < (foxX + fox[0].getWidth())&& foxY < y && y < (foxY + fox[0].getHeight()))
        {
            return true;
        }

        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        if (event.getAction() == MotionEvent.ACTION_DOWN)
        {
            touch = true;

            foxSpeed = -22;
        }
        return true;
    }
}
