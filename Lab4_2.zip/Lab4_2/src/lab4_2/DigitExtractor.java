package lab4_2;

public class DigitExtractor 
{
    private int lastDigit;
    private int number;
    
    public DigitExtractor(int num)
    {
        number = num;
    }
    public int nextDigit()
    {
        lastDigit = number%10;
        number = (int)number/10;
        return lastDigit;
    }
    
}
