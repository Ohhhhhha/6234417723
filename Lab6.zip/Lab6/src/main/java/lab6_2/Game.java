/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;
import java.util.Objects;
import java.util.Random;
import java.util.Scanner;
/**
 *
 * @author Yanisa
 */
public class Game {
    private int com_sc=0;
    private int user_sc=0;
    private String sign;
    private String status;
    private String endword;
    private String[] rps={"ROCK","PAPER","SCISSORS"};


    public void play() {

        String com_rps;
        String user_rps;

        Random randm = new Random();

        Scanner sc = new Scanner(System.in);
        while(Math.abs(com_sc-user_sc)!=2) {

            int rand=randm.nextInt(3);

            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            sign=sc.nextLine();

            if((Objects.equals(sign, "0")||Objects.equals(sign, "1")||Objects.equals(sign, "2"))&&(sign.length()==1)) {

                user_rps=rps[Integer.parseInt(sign)];
                com_rps=rps[rand];

                System.out.println("You enter: "+user_rps);
                System.out.println("Computer: "+com_rps);

                if((user_rps==rps[0]&&com_rps==rps[2])||(user_rps==rps[1]&&com_rps==rps[0])||(user_rps==rps[2]&&com_rps==rps[1])){

                    status = "You win";
                    endword = "Congrats! ";
                    user_sc++;
                    System.out.println(status+"!");

                }else if((user_rps==rps[2]&&com_rps==rps[0])||(user_rps==rps[0]&&com_rps==rps[1])||(user_rps==rps[1]&&com_rps==rps[2])){

                    status = "You lose";
                    endword="Too bad! ";
                    com_sc++;
                    System.out.println(status+"!");

                }else{

                    status = "It's a tie";
                    System.out.println(status);

                }
            }
        }

        System.out.println("----------------------------");
        System.out.println(endword+status+".");
        System.out.println("User Score: "+user_sc);
        System.out.println("Computer score: "+com_sc);

    }
}
