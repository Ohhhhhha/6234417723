package lab6_1;

/**
 *
 * @author Yanisa
 */
public class CannonBall {
    private final double initV;
    private double simS;
    private double simT;
    public static final double G = 9.81;
    public CannonBall(double u){
        initV = u;
    }
    public void simulatedFlight(){
        double v=initV;
        while(v>0){ 
            int t=0;
            
            while(t<100){
                if(v> 0 ){
                simS=simS+(v*0.01);
                v=v-(G*0.01);
                t++;
                }
                else{
                    break;
                }
            }
            simT++;
            if(v > 0 ){
            System.out.println("Distance on "+(int)simT+" sec:"+String.format("%.3f", simS));}
            else{
                simT=simT+(t*0.01)-1;
            }
        }
        System.out.print("Final distance: "+String.format("%.3f", simS));
        System.out.println(" Total time: "+String.format("%.2f", simT));
    }
    public double calculusFlight(double t){
        double ans;
        return ans = (-0.5*G*(t*t))+initV*t;
    }
    public double getSimulatedTime(){
        return simT;
    }
    public double getSimulatedDistance(){
        return simS;
    }
}
    