package lab4_1;

import java.util.Scanner;

public class SodaTester 
{
    public static void main(String[] args)
    {
        Scanner canHeight = new Scanner(System.in);
        System.out.print("Enter Height: ");
        double height = canHeight.nextDouble();
        Scanner canDiameter = new Scanner(System.in);
        System.out.print("Enter diameter: ");
        double diameter = canDiameter.nextDouble();
        SodaCan can = new SodaCan(height,diameter);
        System.out.println("Volume: "+String.format("%.2f",can.getVolume()));
        System.out.println("Surface Area: "+String.format("%.2f",can.getSurfaceArea()));
    }
}
