package lab4_1;

public class SodaCan
{
    private double height;
    private double diameter;   
    
    public SodaCan(double enterHeight, double enterDiameter)
    {
        height = enterHeight;
        diameter = enterDiameter;
    }
    public double getVolume()
    {
        double volume = Math.PI*height*Math.pow(diameter/2, 2);
        return volume;
    }
    public double getSurfaceArea()
    {
        double surfaceArea = (2*Math.PI*Math.pow(diameter/2,2))+(2*Math.PI*(diameter/2)*height);
        return surfaceArea;
    }
}