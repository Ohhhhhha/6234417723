package com.example.guessanumber;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;
public class guess extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guess);
        Button guess = findViewById(R.id.guess);
        final Random ran = new Random();
        final TextView show = findViewById(R.id.showResult);
        final TextView show2 = findViewById(R.id.showResult2);
        final TextView show3 = findViewById(R.id.showResult3);
        final int comNumber = ran.nextInt(100)+1;
        final TextView user = findViewById(R.id.userNumber);
        final int[] cnt = new int[1];
        show3.setText("guess a number");
        guess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent win = new Intent(getApplicationContext(),win.class);

                if (user.getText().toString().length() == 0 || Integer.parseInt(user.getText().toString())> 100){
                    Toast toast = Toast.makeText(getApplicationContext(), "Please guess number 1 - 100", Toast.LENGTH_SHORT);
                    toast.show();
                    user.setText("");

                }
                else if (Integer.parseInt(user.getText().toString())<comNumber){
                    cnt[0] +=1;
                    show.setText("your last enter is "+user.getText().toString());
                    show2.setText("your guess is too low !!");
                    user.setText("");


                }
                else if (Integer.parseInt(user.getText().toString())>comNumber){
                    cnt[0] +=1;
                    show.setText("your last enter is "+user.getText().toString());
                    show2.setText("your guess is too high !!");
                    user.setText("");


                }
                else{
                    win.putExtra("cnt", cnt[0]);
                    startActivity(win);
                    user.setText("");
                    show.setText("");
                    show2.setText("");

                }
            }
        });
    }
}
