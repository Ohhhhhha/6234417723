package com.example.easterday;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.sendButton);
        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i = new Intent(this,MainScreen.class);
        EditText textTime = findViewById(R.id.inputTime);
        String inputYear = textTime.getText().toString();
        i.putExtra("result",easterDay(inputYear));
        startActivity(i);
    }
    public String easterDay(String year){
        String mounth = "";
        int y = Integer.parseInt(year);
        int a = y%19;
        int b = y/100;
        int c = y%100;
        int d = b/4;
        int e = b%4;
        int g = (8*b +13)/25;
        int h = (19*a+b+-d-g+15)%30;
        int j = c/4;
        int k = c%4;
        int m = (a+11*h)/319;
        int r = (2*e+2*j-k-h-m+32)%7;
        int n = (h-m+r+90)/25;
        int p = (h-m+r+n+19)%32;
        switch (n){
            case 1 : mounth = "January";break;
            case 2 : mounth = "February";break;
            case 3 : mounth = "March";break;
            case 4 : mounth = "April";break;
            case 5 : mounth = "May";break;
            case 6 : mounth = "June";break;
            case 7 : mounth = "July";break;
            case 8 : mounth = "August";break;
            case 9 : mounth = "September";break;
            case 10 : mounth = "October";break;
            case 11 : mounth = "November";break;
            case 12 : mounth = "December";break;
        }
        return mounth+" "+p;
    }
}
