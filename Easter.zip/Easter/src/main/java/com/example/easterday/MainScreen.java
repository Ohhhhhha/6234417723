package com.example.easterday;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);
        TextView displayResult = findViewById(R.id.outResult);
        String outPut = getIntent().getStringExtra("result");
        displayResult.setText(outPut);
    }
}
