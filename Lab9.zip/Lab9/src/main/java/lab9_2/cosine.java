/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author Yanisa
 */
public class cosine extends Taylor{
    public cosine(int k,double x){
        super.setlter(k);
        super.setValue(x);
        }
     public double getApprox(){
        return Math.cos(super.getValue());
    }
    public void printValue(){
        double sum=0;
        for(int k =0;k<=super.getlter();k++){
            sum+=(Math.pow(-1,k))*(Math.pow(super.getValue(),(2*k)))/super.factorial((2*k));   
        }
        System.out.println("Value from Math.cos() is "+getApprox()+".");
        System.out.println("Approximated value is "+sum+".");
    }
    
}
