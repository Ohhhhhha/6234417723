package lab5_1;
import java.util.Scanner;
enum Day
{
    SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),THURSDAY("Thursday"),FRIDAY("Friday"),SATURDAY("Saturday");
    public final String dayName;
    private final String dayValue;
    Day(String dayInput)
    {
        this.dayName = dayInput;
        this.dayValue = dayInput;
    }
    public String getDayValue()
    {
        return dayValue;
    }
}
public class Zeller {
        private int h,q,m,j,k,y;
    public void enterYear()
    {
        System.out.print("Enter year (e.g., 2012): ");
        Scanner year=new Scanner(System.in);
        y = year.nextInt();
    }
    public void enterMonth()
    {
        System.out.print("Enter month (1-12): ");
        Scanner month = new Scanner(System.in);
        m = month.nextInt();
        if(m <= 2)
        {
            m+=12;
            y--;
        }
        j = y/100;
        k = y%100;
    }
    public void enterDayOfMonth()
    {
        System.out.print("Enter day of the month (1-31): ");
        Scanner dayOfMonth = new Scanner(System.in);
        q = dayOfMonth.nextInt();
    }
    public Day getDayofweek()
    {
        Day dOutput = Day.SUNDAY;
        h = (q+((26*(m+1))/10)+k+(k/4)+(j/4)+(j*5))%7;
        switch(h)
        {
            case 1: dOutput =Day.SUNDAY; break;
            case 2: dOutput =Day.MONDAY; break;
            case 3: dOutput =Day.TUESDAY; break;
            case 4: dOutput =Day.WEDNESDAY; break;
            case 5: dOutput =Day.THURSDAY; break;
            case 6: dOutput =Day.FRIDAY; break;
            case 0: dOutput =Day.SATURDAY; break;
        }
        return dOutput;
    }
    
}
