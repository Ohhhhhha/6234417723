package lab5_1;

/**
 *
 * @author Yanisa
 */
public class ZellerTester {
    public static void main(String[] args) {
       Zeller zellerTest = new Zeller();
       zellerTest.enterYear();
       zellerTest.enterMonth();
       zellerTest.enterDayOfMonth();
       System.out.println("Day of the week is "+zellerTest.getDayofweek().getDayValue());
    }
    
}
