/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

/**
 *
 * @author Yanisa
 */
public class LineTester {
    public static void main(String[] args) {      
        Line l1 = new Line(-2,1,1,-2);
        Line l2 = new Line(-6,-2,-2,0); 
        System.out.println("Are the two lines equals?: "+l1.equals(l2));
        System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
        System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
        if(l1.isIntersect(l2))
            System.out.printf("Point of intersection: %.2f,%.2f\n",l1.getIntersectionPoint(l2).getX(),l1.getIntersectionPoint(l2).getY());
        
        System.out.println();
        Line l11 = new Line(0,2);
        Line l21 = new Line(2,1);
        System.out.println("Are the two lines equals?: "+l11.equals(l21));
        System.out.println("Are the two lines parallel?: "+l11.isParallel(l21));
        System.out.println("Do the two lines intersect?: "+l11.isIntersect(l21));
        if(l11.isIntersect(l21))
            System.out.printf("Point of intersection: %.2f,%.2f\n",l11.getIntersectionPoint(l21).getX(),l11.getIntersectionPoint(l21).getY());
        
        System.out.println();
        Line l12 = new Line(0.44,3.4);
        Line l22 = new Line(32,32,9);
        System.out.println("Are the two lines equals?: "+l12.equals(l22));
        System.out.println("Are the two lines parallel?: "+l12.isParallel(l22));
        System.out.println("Do the two lines intersect?: "+l12.isIntersect(l22));
        if(l12.isIntersect(l22))
            System.out.printf("Point of intersection: %.2f,%.2f\n",l12.getIntersectionPoint(l22).getX(),l12.getIntersectionPoint(l22).getY());
        
        System.out.println();
        Line l13 = new Line(3,5);
        Line l23 = new Line(5);
        System.out.println("Are the two lines equals?: "+l13.equals(l23));
        System.out.println("Are the two lines parallel?: "+l13.isParallel(l23));
        System.out.println("Do the two lines intersect?: "+l13.isIntersect(l23));
        if(l13.isIntersect(l23))
            System.out.printf("Point of intersection: %.2f,%.2f\n",l13.getIntersectionPoint(l23).getX(),l13.getIntersectionPoint(l23).getY());
        
        System.out.println();
        Line l14 = new Line(0,4);
        Line l24 = new Line(5);
        System.out.println("Are the two lines equals?: "+l14.equals(l24));
        System.out.println("Are the two lines parallel?: "+l14.isParallel(l24));
        System.out.println("Do the two lines intersect?: "+l14.isIntersect(l24));
        if(l14.isIntersect(l24))
            System.out.printf("Point of intersection: %.2f,%.2f\n",l14.getIntersectionPoint(l24).getX(),l14.getIntersectionPoint(l24).getY());
        
        System.out.println();
        Line l15 = new Line(0.44,3.4);
        Line l25 = new Line(0.44,5); 
        System.out.println("Are the two lines equals?: "+l15.equals(l25));
        System.out.println("Are the two lines parallel?: "+l15.isParallel(l25));
        System.out.println("Do the two lines intersect?: "+l15.isIntersect(l25));
        if(l15.isIntersect(l25))
            System.out.printf("Point of intersection: %.2f,%.2f\n",l15.getIntersectionPoint(l25).getX(),l15.getIntersectionPoint(l25).getY());
        
        System.out.println();
        Line l16 = new Line(1,-24);
        Line l26 = new Line(29,5,53,29); 
        System.out.println("Are the two lines equals?: "+l16.equals(l26));
        System.out.println("Are the two lines parallel?: "+l16.isParallel(l26));
        System.out.println("Do the two lines intersect?: "+l16.isIntersect(l26));
        if(l16.isIntersect(l26))
            System.out.printf("Point of intersection: %.2f,%.2f\n",l16.getIntersectionPoint(l26).getX(),l16.getIntersectionPoint(l26).getY());
        
    }
}
