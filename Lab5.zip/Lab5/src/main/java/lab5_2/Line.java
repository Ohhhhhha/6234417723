package lab5_2;
/**
 *
 * @author Yanisa
 */
import java.awt.geom.Point2D;
import java.lang.Double;
public class Line {
    private double x,b,m,xi,yi;
    public Line(double x2, double y2, double mi)
    {   
        this.m=mi;
        this.b=y2-(mi*x2);
        if(mi==0)
            this.x = Double.NaN;
        else
            this.x=((mi*x2)-y2)/mi;
        
    }
    public Line(double x1, double y1, double x2, double y2) 
    {
        if(x2-x1==0)
        {
            this.m = Double.NaN;
            this.b = Double.NaN;
        }
        else
        {
            this.m =(y2-y1)/(x2-x1);
            this.b= y2-(this.m*x2);
        }
        if(m==0)
            this.x = Double.NaN;
        else
            this.x=((this.m*x2)-y2)/this.m;
    }
    public Line(double mi, double b)
    {
        this.m=mi;
        this.b=b;
        if(mi==0)
            this.x = Double.NaN;
        else
            this.x=((-b)/mi);
    }
    public Line(double a) 
    {
        this.x=a;
        this.m = Double.NaN;
        this.b = Double.NaN;
    }
    
    public boolean isParallel(Line line)
    {
        if(line.m == this.m || (line.m == Double.NaN && this.m == Double.NaN)) 
            return true;
        else    
            return false;
    }
    
    public boolean equals(Line line)
    {
        if((line.m == this.m || (line.m == Double.NaN && this.m == Double.NaN)) && line.x == this.x && line.b == this.b)
            return true;
        else    
            return false;
    }
    
    public boolean isIntersect(Line line)
    {
      if(Double.isFinite((line.b-this.b)/(this.m-line.m)) || (Double.isFinite(line.m)&&Double.isNaN(this.m)) || (Double.isFinite(this.m)&&Double.isNaN(line.m)) )
           return true;
        else    
           return false;
    }
    
    public Point2D.Double getIntersectionPoint(Line line) 
    {
        if (Double.isFinite(line.m)&&Double.isNaN(this.m))
        {
            this.xi = this.x;
            this.yi = (this.m*this.xi)+this.b;
        }
        else if (Double.isFinite(this.m)&&Double.isNaN(line.m))
                {
                    this.xi = line.x;
                    this.yi = (this.m*this.xi)+this.b;
                }
        else
        {
        this.xi = ((line.b-this.b)/(this.m-line.m));
        this.yi = (this.m*this.xi)+this.b;
        }
        return new Point2D.Double(this.xi,this.yi);
    }
    
}
